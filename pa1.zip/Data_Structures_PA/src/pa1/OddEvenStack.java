package pa1;

import java.util.Arrays;

public class OddEvenStack {

    private int maxStackSize, oddTos, evenTos;
	private int[] stack;

	public OddEvenStack(int maxStackSize) { 
		this.maxStackSize = maxStackSize;
		this.stack = new int[maxStackSize];
		Arrays.fill(this.stack, 0);
		this.evenTos = maxStackSize;
		this.oddTos = -1;
	}

	public void push(int val) {
		if (evenTos == oddTos+1) {
			System.out.print("Cannot push. Stack is full");
		}
		else if (val%2 ==1) {
			oddTos++;
			stack[oddTos] = val;
			
			
		}
		else {
			evenTos--;
			stack[evenTos] = val;
			
		}
		}
	

	public int popOdd() { 
		if(oddTos ==-1  ) {
			System.out.print("Cannot pop. there is no odd");
			return 0;
			
		}
		else {
		int y = stack[oddTos];
		oddTos--;
		return y;
		}
	
		
		
	}

	public int popEven() {
		if(evenTos == maxStackSize) {
			System.out.print("Cannot pop. there is no even");
			return 0;
		}
		
		
		
		else {
			int y = stack[evenTos];
			evenTos++;
			return y;
		}

	}
	

	public int size() {
		return oddTos + 1 + (maxStackSize-evenTos);
	}
	
	public String toString() {
		return Arrays.toString(stack);
	}
}