package pa1;

public class Sorting {

	public static void selectionSort(int[] array, int arrayLen) { 
		for(int i=0; i<arrayLen; i++) {
			int index = i;
			for(int j=i+1;j<arrayLen;j++) {
				if(array[j]<array[index]) {
					index = j;
				}
			}
			int smaller = array[index];
			array[index] = array[i];  
            array[i] = smaller;  
			
		}
	}

	public static void insertionSort(int[] array, int arrayLen) { 

		for(int i=0; i<arrayLen;i++) {
			int index = array[i];
			int j=i-1;
			while((j>-1) && (array[j]>index)) {
				  array[j+1] = array[j];  
	                j--;  
	            }  
	            array[j+1] = index;  
	        
			}
		}
	}

